﻿namespace crawlWebsiteAndExtractInfo
{
    partial class frmCrawlWebsite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCrawlWebsite));
            this.btnCrawlWebsiteHtml = new System.Windows.Forms.Button();
            this.lblUrlToCrawl = new System.Windows.Forms.Label();
            this.txbUrlToCrawl = new System.Windows.Forms.TextBox();
            this.txbExtractedInfo = new System.Windows.Forms.TextBox();
            this.lblExtractedInfo = new System.Windows.Forms.Label();
            this.lblCrawledHtml = new System.Windows.Forms.Label();
            this.btnExtractInfo = new System.Windows.Forms.Button();
            this.rtbExtractedHtml = new System.Windows.Forms.RichTextBox();
            this.lklTutorialUrl = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // btnCrawlWebsiteHtml
            // 
            this.btnCrawlWebsiteHtml.Location = new System.Drawing.Point(112, 35);
            this.btnCrawlWebsiteHtml.Name = "btnCrawlWebsiteHtml";
            this.btnCrawlWebsiteHtml.Size = new System.Drawing.Size(143, 45);
            this.btnCrawlWebsiteHtml.TabIndex = 0;
            this.btnCrawlWebsiteHtml.Text = "抓取网页html源码";
            this.btnCrawlWebsiteHtml.UseVisualStyleBackColor = true;
            this.btnCrawlWebsiteHtml.Click += new System.EventHandler(this.btnCrawlAndExtract_Click);
            // 
            // lblUrlToCrawl
            // 
            this.lblUrlToCrawl.AutoSize = true;
            this.lblUrlToCrawl.Location = new System.Drawing.Point(12, 12);
            this.lblUrlToCrawl.Name = "lblUrlToCrawl";
            this.lblUrlToCrawl.Size = new System.Drawing.Size(106, 13);
            this.lblUrlToCrawl.TabIndex = 1;
            this.lblUrlToCrawl.Text = "要抓取的网页地址:";
            // 
            // txbUrlToCrawl
            // 
            this.txbUrlToCrawl.BackColor = System.Drawing.SystemColors.Info;
            this.txbUrlToCrawl.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txbUrlToCrawl.Location = new System.Drawing.Point(121, 9);
            this.txbUrlToCrawl.Name = "txbUrlToCrawl";
            this.txbUrlToCrawl.ReadOnly = true;
            this.txbUrlToCrawl.Size = new System.Drawing.Size(209, 20);
            this.txbUrlToCrawl.TabIndex = 2;
            this.txbUrlToCrawl.Text = "http://www.songtaste.com/user/351979/";
            // 
            // txbExtractedInfo
            // 
            this.txbExtractedInfo.BackColor = System.Drawing.SystemColors.Info;
            this.txbExtractedInfo.Location = new System.Drawing.Point(121, 263);
            this.txbExtractedInfo.Name = "txbExtractedInfo";
            this.txbExtractedInfo.ReadOnly = true;
            this.txbExtractedInfo.Size = new System.Drawing.Size(209, 20);
            this.txbExtractedInfo.TabIndex = 3;
            // 
            // lblExtractedInfo
            // 
            this.lblExtractedInfo.AutoSize = true;
            this.lblExtractedInfo.Location = new System.Drawing.Point(12, 266);
            this.lblExtractedInfo.Name = "lblExtractedInfo";
            this.lblExtractedInfo.Size = new System.Drawing.Size(94, 13);
            this.lblExtractedInfo.TabIndex = 4;
            this.lblExtractedInfo.Text = "提取出来的内容:";
            // 
            // lblCrawledHtml
            // 
            this.lblCrawledHtml.AutoSize = true;
            this.lblCrawledHtml.Location = new System.Drawing.Point(12, 83);
            this.lblCrawledHtml.Name = "lblCrawledHtml";
            this.lblCrawledHtml.Size = new System.Drawing.Size(106, 13);
            this.lblCrawledHtml.TabIndex = 6;
            this.lblCrawledHtml.Text = "抓取到的网页源码:";
            // 
            // btnExtractInfo
            // 
            this.btnExtractInfo.Location = new System.Drawing.Point(112, 197);
            this.btnExtractInfo.Name = "btnExtractInfo";
            this.btnExtractInfo.Size = new System.Drawing.Size(143, 45);
            this.btnExtractInfo.TabIndex = 7;
            this.btnExtractInfo.Text = "提取所需的信息";
            this.btnExtractInfo.UseVisualStyleBackColor = true;
            this.btnExtractInfo.Click += new System.EventHandler(this.btnExtractInfo_Click);
            // 
            // rtbExtractedHtml
            // 
            this.rtbExtractedHtml.BackColor = System.Drawing.SystemColors.Info;
            this.rtbExtractedHtml.DetectUrls = false;
            this.rtbExtractedHtml.HideSelection = false;
            this.rtbExtractedHtml.Location = new System.Drawing.Point(15, 99);
            this.rtbExtractedHtml.Name = "rtbExtractedHtml";
            this.rtbExtractedHtml.ReadOnly = true;
            this.rtbExtractedHtml.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.rtbExtractedHtml.Size = new System.Drawing.Size(315, 92);
            this.rtbExtractedHtml.TabIndex = 8;
            this.rtbExtractedHtml.Text = "";
            // 
            // lklTutorialUrl
            // 
            this.lklTutorialUrl.AutoSize = true;
            this.lklTutorialUrl.Location = new System.Drawing.Point(42, 308);
            this.lklTutorialUrl.Name = "lklTutorialUrl";
            this.lklTutorialUrl.Size = new System.Drawing.Size(279, 13);
            this.lklTutorialUrl.TabIndex = 9;
            this.lklTutorialUrl.TabStop = true;
            this.lklTutorialUrl.Text = "【教程】抓取网并提取网页中所需要的信息 之 C#版";
            this.lklTutorialUrl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lklTutorialUrl_LinkClicked);
            // 
            // frmCrawlWebsite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 333);
            this.Controls.Add(this.lklTutorialUrl);
            this.Controls.Add(this.rtbExtractedHtml);
            this.Controls.Add(this.btnExtractInfo);
            this.Controls.Add(this.lblCrawledHtml);
            this.Controls.Add(this.lblExtractedInfo);
            this.Controls.Add(this.txbExtractedInfo);
            this.Controls.Add(this.txbUrlToCrawl);
            this.Controls.Add(this.lblUrlToCrawl);
            this.Controls.Add(this.btnCrawlWebsiteHtml);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCrawlWebsite";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "抓取网页并提取所需信息 演示";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCrawlWebsiteHtml;
        private System.Windows.Forms.Label lblUrlToCrawl;
        private System.Windows.Forms.TextBox txbUrlToCrawl;
        private System.Windows.Forms.TextBox txbExtractedInfo;
        private System.Windows.Forms.Label lblExtractedInfo;
        private System.Windows.Forms.Label lblCrawledHtml;
        private System.Windows.Forms.Button btnExtractInfo;
        private System.Windows.Forms.RichTextBox rtbExtractedHtml;
        private System.Windows.Forms.LinkLabel lklTutorialUrl;
    }
}

